package com.example.com.parsingData.enumType;

public enum RequestType {
    AUTHOR_SHOW,
    BOOK_SHOW, 
    SEARCH_BOOKS,
    USER_INFO;
}
