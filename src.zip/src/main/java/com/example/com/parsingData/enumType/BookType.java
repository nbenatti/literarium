package com.example.com.parsingData.enumType;

public enum BookType {
    SAVED_BOOK,
    RECEIVED_BOOK,
}
