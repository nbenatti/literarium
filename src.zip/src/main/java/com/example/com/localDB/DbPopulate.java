package com.example.com.localDB;


public class DbPopulate {

    public static void main(String[] args) {

        LocalDatabase db;
    }

    /*public void createDb(LocalDatabase db, BookDAO bookDao) {
        Context context = ;
        db = Room.inMemoryDatabaseBuilder(context, db.class).build();
        bookDao = db.getBookDAO();
    }*/

}
