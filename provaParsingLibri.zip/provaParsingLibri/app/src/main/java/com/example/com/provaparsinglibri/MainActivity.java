package com.example.com.provaparsinglibri;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.concurrent.ExecutionException;

public class MainActivity extends Activity {

    private ImageView img;
    private TextView name;
    private TextView fansCount;
    private TextView homeTown;
    private TextView numBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_author_show);

        img = findViewById(R.id.auth_image);
        name = findViewById(R.id.auth_name);
        fansCount = findViewById(R.id.auth_fanscount);
        homeTown = findViewById(R.id.auth_hometown);
        numBooks = findViewById(R.id.auth_nbooks);

        // the id will come from a Bundle
        Author author = null;
        GetAuthorData task = new GetAuthorData(this, 1000);
        task.execute();
    }

    public void loadAuthorData(Author a) {

        name.setText(a.getName());
        fansCount.setText(String.valueOf(a.getFansCount()));
        //load image on UI
        Picasso.get().load(a.getLargeImageURL()).into(img);
        homeTown.setText(a.getHomeTown());
        numBooks.setText(String.valueOf(a.getNumBooks()));
    }
}
