/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.android.provaparsinglibri;
/**
 *
 * @author Francesco Rocca
 */
public enum SearchType {
    SEARCH_BY_BOTH,
    SEARCH_BY_AUTHOR,
    SEARCH_BY_TITLE;

    public String searchTypeString() {
        switch (this) {
            case SEARCH_BY_AUTHOR:
                return "author";
            case SEARCH_BY_TITLE:
                return "title";
            default:
                return "all";
        }
    }
}
