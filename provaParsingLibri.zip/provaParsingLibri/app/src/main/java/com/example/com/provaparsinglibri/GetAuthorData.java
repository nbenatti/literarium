package com.example.com.provaparsinglibri;

import android.os.AsyncTask;
import android.util.Log;

import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

public class GetAuthorData extends AsyncTask {

    private MainActivity ref;

    private String xmlContent;  // content returned by the server

    private URL url;

    private HttpURLConnection httpConn;

    private int authorId;

    public GetAuthorData(MainActivity ref, int authorId) {

        this.ref = ref;
        this.authorId = authorId;
    }

    @Override
    protected Object doInBackground(Object[] objects) {

        String requestURLString = URLRequestFormatter.format(RequestType.AUTHOR_SHOW, String.valueOf(authorId));

        Log.d("REQ_URL", requestURLString);

        // send request
        try {
            url = new URL(requestURLString);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        Author author = null;

        try {
            author = XmlDataParser.parseAuthor(url.openStream());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }

        return author;
    }

    @Override
    protected void onPostExecute(Object o) {

        Author author = (Author)o;

        ref.loadAuthorData(author);
    }
}
