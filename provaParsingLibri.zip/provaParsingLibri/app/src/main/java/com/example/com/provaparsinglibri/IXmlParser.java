package com.example.com.provaparsinglibri;

public interface IXmlParser {
}
