package com.example.android.provaparsinglibri;

import android.os.AsyncTask;
import android.util.Log;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class GetUserDataTask extends AsyncTask {

    private MainActivity ref;

    private String xmlContent;  // content returned by the server

    private URL conn;

    public GetUserDataTask(MainActivity ref) {
        this.ref = ref;
    }

    @Override
    protected Object doInBackground(Object[] objects) {

        String requestURL = URLRequestFormatter.format(RequestType.AUTHOR_SHOW, "18541");

        // send request

        try {
            conn = new URL(requestURL);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        XmlDataParser parser = new XmlDataParser();

        try {
            List res = parser.parse(conn.openStream());
            Log.d("EBBENE", res.toString());
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
