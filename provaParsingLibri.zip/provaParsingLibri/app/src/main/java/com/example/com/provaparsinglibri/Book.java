package com.example.com.provaparsinglibri;

public class Book {

    private String title;
    private String isbn;
    private String imageURL, smallImageURL, largeImageURL;
    private int publicationYear;
    private String publisher;
    private String description;
    private String amazonBuyLink;
    private int numPages;

    public Book(String title, String isbn,
                String imageURL, String smallImageURL, String largeImageURL,
                int publicationYear, String publisher, String description,
                String amazonBuyLink, int numPages) {
        this.title = title;
        this.isbn = isbn;
        this.imageURL = imageURL;
        this.smallImageURL = smallImageURL;
        this.largeImageURL = largeImageURL;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.description = description;
        this.amazonBuyLink = amazonBuyLink;
        this.numPages = numPages;
    }
}
