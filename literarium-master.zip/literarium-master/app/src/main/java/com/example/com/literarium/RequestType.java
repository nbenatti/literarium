package com.example.com.literarium;

public enum RequestType {
    GEO_REPORT,
    LOG_POSITION
}
